#include "StdAfx.h"
#include "Question2.h"

