#include "StdAfx.h"
#include "Training.h"

